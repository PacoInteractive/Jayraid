JAYRAID LAUNCHER
================

Welcome to the Jayraid closed alpha, and thank you for testing!


GETTING STARTED
1. Install the .NET 8 Desktop Runtime (free, from Microsoft) if you do not have it yet:
   https://dotnet.microsoft.com/download/dotnet/8.0
2. Keep all files of this folder together. Start Jayraid-Launcher.exe.
3. The launcher asks for your tester code. Type it in, or drag your code file
   (Jayraid-Tester-Code.txt) into the launcher window.
4. Click INSTALL, then PLAY.

New versions arrive by themselves: when there is an update, the big button
turns into UPDATE. The launcher updates itself the same way.


IF WINDOWS BLOCKS THE LAUNCHER
SmartScreen or Smart App Control may warn you because the launcher is new and
not yet known to Microsoft. Click "More info" and then "Run anyway". If that
button is missing, right click Jayraid-Launcher.exe, choose Properties and tick
"Unblock".


WHAT TO TEST
Play the way you like. Things that help me most:
  - anything that crashes, freezes or stutters
  - anything that felt unfair, confusing or boring
  - ideas for what Jayraid should get next
Please tell me which version you played (shown in the main menu of the game,
for example "Alpha 1.36.0").


USEFUL FOLDERS
Your worlds:          %AppData%\Blockwelt2\worlds
Installed versions:   %LocalAppData%\Blockwelt2\Versionen
Stutter report:       %AppData%\Blockwelt2\ruckler.txt  (shows what slowed the game down)


YOUR CODE
Your tester code is personal. Please do not share it. A shared code can be
blocked, and then the launcher locks again.

Have fun!
